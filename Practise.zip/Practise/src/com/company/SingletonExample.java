package com.company;

public final class SingletonExample{

    private static SingletonExample INSTANCE;

    private SingletonExample(){

    }

    private static SingletonExample getInstance(){
        if(INSTANCE == null){
            return  new SingletonExample();
        }
        return INSTANCE;
    }

}
