package com.company;

import java.awt.image.BufferedImageFilter;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

//palindrome

public class Palindrome {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter your number ");
        int num = Integer.parseInt(br.readLine());
       palindrome(num);
    }

    private static void palindrome(int num){

        int temp = num;
        int rev = 0;

        while(num!=0){
            int digit = num%10;
            rev = rev*10 +digit;
            num=num/10;
        }
        if (rev == temp){
            System.out.println("number is palindrome");
        }
        else
            System.out.println("number is not palindrome");

    }
}
