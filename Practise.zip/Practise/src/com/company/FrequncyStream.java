package com.company;

import javax.swing.plaf.basic.BasicListUI;
import java.util.Arrays;
import java.util.HashMap;

import static java.util.Arrays.asList;
import static java.util.Arrays.spliterator;

public class FrequncyStream {
    public static void main(String[] args) {

        String str = "i love i love you";
        char [] ch =str.toCharArray();

        var freq = new HashMap<String,Integer>();


        asList(str.split(" ")).forEach(s -> {
            if(freq.containsKey(s)){
                Integer count = freq.get(s);
                freq.put(s,count+1);
            }
            else
                freq.put(s,1);
        });

        System.out.println(freq.toString());

    }}

