package com.company;

public class ReverseArray {
    public static void main(String[] args) {
        int arr[]= {32,43,44,66,77};
        reverse(arr);
    }

     static void reverse(int arr[]){

        int c = 0;
        int[] arr2=new int[5];
        for(int i = 4; i>=0; i--){
           arr2[c]=arr[i];
           System.out.println(arr[c]);
           c++;
        }

    }
}
