package com.company;

import java.util.HashMap;

public class Steam1 {

    public static void main(String[] args) {
        var productPrice = new HashMap<String,Double>();
        productPrice.put("Ram",121.9);
        productPrice.put("Sam",121.8);
        productPrice.put("Tam",121.4);

        productPrice.forEach((key,value)->{
            System.out.print("Keys : "+key);
            System.out.println(" " +
                    "values: "+value);

        });

    }
}
