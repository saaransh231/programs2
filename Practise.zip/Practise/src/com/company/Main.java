package com.company;

public class Main {

    public static class PalindromeString {
        public static void main(String[] args) {
            String str = "MAMu\\";
            palin(str);
        }

        private static void palin(String str) {
            String str2 = "";
            for(int i=str.length()-1; i>=0;i--) {
                str2 = str2 + str.charAt(i);
            }
            if(str2.toLowerCase().equals(str.toLowerCase())){
                System.out.println("its palindrome");
            }
            System.out.println("not palindrome");
        }
    }
}