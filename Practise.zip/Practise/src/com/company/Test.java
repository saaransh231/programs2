package com.company;

import javax.swing.plaf.basic.BasicListUI;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import static java.util.Arrays.asList;


public class Test {

    public static void main(String[] args) throws IOException {

     String str = "i love my love i india";

     var freq = new HashMap<String , Integer>();

        asList(str.split(" ")).forEach(s->{
            if(freq.containsKey(s)){
                int count = freq.get(s);
                freq.put(s,count+1);
            }
            else
                freq.put(s,1);
        });
        System.out.println(freq.toString());


    }
}
