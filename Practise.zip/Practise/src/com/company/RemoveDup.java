package com.company;

import java.util.Arrays;
import java.util.LinkedHashSet;

public class RemoveDup {

    public static void main(String[] args) {
        String str = "Java developer";

        LinkedHashSet<Character> set = new LinkedHashSet<>();
        for(int i = 0; i<str.length();i++){
            set.add(str.charAt(i));
        }

            System.out.print(set.toString());
        }

    }

