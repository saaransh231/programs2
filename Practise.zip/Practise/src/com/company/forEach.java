//package com.company;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;
//import java.util.Optional;
//import java.util.stream.Collectors;
//
//public class forEach {
//    public static void main(String arge[]){
//        List<Product> productList = new ArrayList<>();
//
//        productList.add( new Product(1,"hp",2500));
//        productList.add( new Product(12,"lenopvo",3500));
//        productList.add( new Product(1,"sony",4500));
//        productList.stream().forEach(product -> System.out.println(product));
//
////        Optional<String> checkNull = Optional.ofNullable(str[5]);
////        Optional<String> chexknull = Optional.ofNullable(7).;
//
//    }
//
//}
//
//
