package com.company;

import java.util.*;
import java.util.stream.Collectors;

public class Stream4 {
    public static void main(String[] args) {
//       List<String> str = new ArrayList<>();
//       str.add("ram");
//       str.add("sham");
//       str.add("palti");

        List<Integer> arr = Arrays.asList(22,33,22,33,43,23,43,33);


       arr.stream()
                       .filter(i->Collections.frequency(arr,i)>1)
                               .collect(Collectors.toList())
                                       .forEach(System.out::println);








//
//       String str2 = str.stream()
//               .findFirst()
//               .orElse(null);
//        System.out.println(str2);


    }
}
