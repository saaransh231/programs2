package com.company;

public class MainThread
{
    public static void main(String[] args) throws InterruptedException {
        Thread1 obj1 = new Thread1("Thread 1 obj 1");
        Thread1 obj2 = new Thread1("Thread 2 obj 2");
        Thread t1 = new Thread(obj1);
        Thread t2 = new Thread(obj2);
        t1.start();
        t1.join();
        t2.start();

    }
}
