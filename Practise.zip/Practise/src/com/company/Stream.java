package com.company;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Stream {

    public static void main(String arge[]){
        List<Product> productList = new ArrayList<>();

        productList.add( new Product(1,"hp",2500));
        productList.add( new Product(12,"lenopvo",3500));
        productList.add( new Product(1,"sony",4500));
        List<Float> productPriceList = productList.stream()
                .filter(p -> p.price>3000)
                .map(p-> p.price)
                .collect(Collectors.toList());
        System.out.println(productList);

    }
}
