package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class Frequency {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int arr[] = {33, 65, 88, 66, 88};
        int size = 4;
        frequency(arr, size);
    }

    static void frequency(int arr[], int size) {

        Map<Integer, Integer> map = new HashMap<>();
        for (int i = 0; i < size; i++) {
            if (map.containsKey(arr[i])) {
                map.put(arr[i], map.get(arr[i + 1]));
            } else {
                map.put(arr[i], 1);
            }

        }

        System.out.println(map.toString());
//        for (Map.Entry<Integer, Integer> entry : map.entrySet()) {

        for(Map.Entry<Integer,Integer> entry :map.entrySet()){
            entry.getKey() + entry.getValue()



        for (int Map = 0; Map < ; Map++) {

        }
//            System.out.println(entry.getKey() + " " + entry.getValue());
//        }
    }
}
