package com.company;

import java.util.ArrayList;
import java.util.List;

public class Nonrepetative {
    public static void main(String[] args) {


        List<String>list = new ArrayList<String>();
        list.add("Ram");
        list.add("sham");

        list.stream()
                .filter((s)->s.startsWith("R"))
                .map(String::toLowerCase)
                .forEach(System.out::println);


        }
    }
