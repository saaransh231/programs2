package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class TUF {
    static void issorted(int arr[], int n) {
        int c = 0;
        for (int i = 1; i < n; i++) {
            if (arr[i+1] < arr[i]) {
                c = 1;
                break;

            }
        }

        if (c == 1) {
            System.out.println("sorted");
        }

    }


    public static void main(String args[]) {
        int arr[] = {1, 2, 3, 7, 5}, n = 5;

      issorted(arr, n);
    }
}
