package com.company;

public class Norep2 {
    public static void main(String[] args) {

        String str = "aava";

        for (char ch : str.toCharArray()){
            if(str.indexOf(ch)==str.lastIndexOf(ch)){
                System.out.println(ch);
            }
        }
    }


}