package com.company;

import java.awt.image.BufferedImageFilter;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

//palindrome

public class Prime {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter your number ");
        int num = Integer.parseInt(br.readLine());
        prime(num);
    }

    public static void prime(int num){

        int temp = num;
        int rev = 0;
        int c = 0;

        for(int i = 2 ; i < num ; i++){
            if (num%i == 0){
                c++;
            }
        }
        if(c>0){
            System.out.println("number is not prime");
        }
        else
            System.out.println("number is prime");

    }
}
