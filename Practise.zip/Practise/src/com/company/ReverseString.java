package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Locale;

public class ReverseString {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("enter your string");
        String str = br.readLine();
        reverseStr(str);
    }

    private static void reverseStr(String str) {
        String rev = "";
        for(int i = str.length()-1;i>=0;i--){
            rev = rev +str.charAt(i);
        }
        if(str.toLowerCase().equals(rev.toLowerCase())){
            System.out.println("its palindrome");
        }
        else {
            System.out.println("its not palindrome");
        }
    }
}

