package com.company;

import java.awt.*;

class Thread1 implements Runnable {

    String message;

    Thread1(String msg){
        message = msg;
    }


    @Override
    public void run() {

        for (int i = 0; i< 5; i++){
            try {
                System.out.println("Run method :"+message);
                Thread.sleep(400);
            }
            catch (InterruptedException ie){
                System.out.println("Exception");
            }
        }

    }
}


