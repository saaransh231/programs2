package com.company;

import java.util.HashMap;

public class Charfrequency {

    public static void main(String[] args) {
        String str = "Java developer";

        HashMap<Character, Integer> map = new HashMap<Character, Integer>();

        for (int i = 0; i < str.length(); i++) {

            char ch = str.charAt(i);

            Integer vaue = map.get(ch);

            if (vaue != null) {
                map.put(ch, vaue + 1);
            } else
                map.put(ch, 1);


        }
        System.out.println(map.toString());


    }
}
