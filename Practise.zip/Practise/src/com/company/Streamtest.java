package com.company;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Streamtest {
    public static void main(String[] args) {
        ArrayList<Product> product = getUnsortedProductList();


//        list.add("Bijay");
//        list.add("Sanjay");
//        list.add("Anand");
//        long str = list.stream().
//                filter((s)-> (s.startsWith("A"))).
//                map(String::toUpperCase).
//                count();
//        System.out.println(str);


//        list.stream().sorted()
//                .map(String::toUpperCase)
//                .forEach(System.out::println);

        Comparator<Product> compareByName = Comparator
                .comparing(Product::getPrice)
                .thenComparing(Product::getName);


        List<Product> sortedProduct = product.stream()
                .sorted(compareByName)
                .distinct()
                .collect(Collectors.toList());
        System.out.println(sortedProduct);

    }
       private static ArrayList<Product> getUnsortedProductList(){
        ArrayList<Product>list= new ArrayList<>();
        list.add(new Product(11, "jay", 2200));
        list.add(new Product(12, "ajay", 2200));
        list.add(new Product(13, "sajay", 2100));
        list.add(new Product(14, "bijay", 2500));
        return list;
}
}
