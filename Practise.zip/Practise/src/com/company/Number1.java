package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

//to find length of the number

public class Number1 {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("enter your number");
        int i = Integer.parseInt(br.readLine());
        System.out.println("length of the number is " + findlegth(i));

    }

    public static Integer findlegth(Integer i){

        String s = Integer.toString(i);
        return s.length();
    }
}
