package com.company;

import java.util.Arrays;
import java.util.List;

public class Streamcount {
    public static void main(String[] args) {
        List<String > list = Arrays.asList("abc","jhh"," ");
//        Long count = list.stream()
//                .filter(x->x.contains("a"))
//                .map(String::toUpperCase)
//                        .count();

        list.stream()
                .filter(x->x.contains("j"))
                .map(String::toUpperCase)
                .forEach(System.out::println);




    }
}
