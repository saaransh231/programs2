package com.company;

import java.util.HashMap;

import static java.util.Arrays.asList;

public class FreqP {
    public static void main(String[] args) {
        String str2 = " i love my India i love";

        var freq = new HashMap<String,Integer>();

        asList(str2.split(" ")).forEach(s -> {
            if(freq.containsKey(s)){
                Integer count = freq.get(s);
                freq.put(s,count+1);
            }
            else
                freq.put(s,1);
        });
        System.out.println(freq.toString());

    }
}
