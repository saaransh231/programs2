package com.company;


import java.util.Arrays;

public class Reverse {

    public static void main(String[] args) {


    int n = 5,j,i;

    for(i = n ;i>0;i--){
        for (j= 1;j<=1;j++){
            System.out.print(j);

        }
        System.out.println("");

    }


}
}


