package com.company;

public class RemoveDuplicates {
    public static void main(String[] args) {
        int array[] = {22,12,22,32,22,32,22};
        System.out.println(remove(array));
    }
    public static int remove(int [] array){
        int i = 0;
        for(int j = 1;i<array.length-1;j++){
            if(array[i]!=array[j]){
                i++;
                array[i]=array[j];
            }
        }
        return i +1;
    }
}
