package programs;

import java.util.HashMap;
import java.util.Map;

import static java.util.Arrays.asList;

public class Wordfrequency {
    public static void main(String[] args) {
        String str = "I love my India i love my";

        var freq = new HashMap<String,Integer>();
        asList(str.split(" ")).forEach(s->{

            if(freq.containsKey("my")){
                Integer count = freq.get(s);
                freq.put(s,count+1);
            }
            else
                freq.put(s,1);
        });
        System.out.println(freq.toString());
    }
}
