package programs;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Frequency {
    public static void main(String[] args) {

        int array[] = {10, 7, 8, 1, 8, 7, 6};

        for(int i =0; i<7; i++) {
            for (int j = 1; j < i; j++) {

                if (array[j] == array[i]) {
                    System.out.println(array[j]);
                }

            }
        }
                }
}
