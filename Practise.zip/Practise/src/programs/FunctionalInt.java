package programs;

interface funInterFace {
    public int sum(int a, int b);

}

public class FunctionalInt {
    public static void main(String[] args) {
       funInterFace summ = (a,b)->a+b;
        System.out.println(summ.sum(55,77));
    }

}
